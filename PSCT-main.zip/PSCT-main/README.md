# PSCT
Project code for C language

These codes are written in C language.

